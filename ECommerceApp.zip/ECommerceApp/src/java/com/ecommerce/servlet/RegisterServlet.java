package com.ecommerce.servlet;

import com.ecommerce.connection.DBConnection;
import com.ecommerce.dao.UserDao;
import com.ecommerce.model.User;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet(name = "RegisterServlet", urlPatterns = {"/register-servlet"})
public class RegisterServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
           
            String name = request.getParameter("register-name");
            String email = request.getParameter("register-email");
            String password = request.getParameter("register-password");
            
            User userModel = new User();
            userModel.setName(name);
            userModel.setEmail(email);
            userModel.setPassword(password); // Remember to HASH passwords in a real application!
            
            try {
                UserDao udao = new UserDao(DBConnection.getConnection());
                boolean result = udao.userRegister(userModel);
                
                if(result){
                    response.sendRedirect("login.jsp");
                } else {
                    out.println("<h1>Registration Failed</h1>");
                    out.println("<p>Something went wrong. <a href='register.jsp'>Try again</a>.</p>");
                }
                
            } catch (ClassNotFoundException | SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
