package com.ecommerce.connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
    private static Connection connection = null;

    public static Connection getConnection() throws ClassNotFoundException, SQLException {
        if (connection == null || connection.isClosed()) {
            // Step 1: Loading the JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            // Step 2: Establishing a connection
            // Replace "your_database", "your_username", and "your_password" with your actual credentials
            String url = "jdbc:mysql://localhost:3306/ecommerce_db?useSSL=false";
            String username = "root"; // Your DB username
            String password = "root"; // Your DB password
            
            connection = DriverManager.getConnection(url, username, password);
            System.out.println("Connected to the database!");
        }
        return connection;
    }
}
